import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShoppingBag, Heart, Search, User, Menu, X, Star, ChevronRight,
  Filter, ChevronDown, Minus, Plus, Trash2, CreditCard,
  Truck, Shield, RotateCcw, Package
} from "lucide-react";

const categories = [
  { id: "all", name: "Tous" },
  { id: "sneakers", name: "Sneakers" },
  { id: "running", name: "Running" },
  { id: "lifestyle", name: "Lifestyle" },
  { id: "basketball", name: "Basketball" },
];

const products = [
  {
    id: 1,
    name: "Air Max 90",
    brand: "Nike",
    price: 149.99,
    originalPrice: 179.99,
    image: "https://images.unsplash.com/photo-1605348532760-6753d2c43329?w=500",
    category: "sneakers",
    rating: 4.8,
    reviews: 234,
    colors: ["#1a1a1a", "#ffffff", "#dc2626"],
    sizes: [39, 40, 41, 42, 43, 44, 45],
    badge: "Promo",
    new: false,
  },
  {
    id: 2,
    name: "UltraBoost 22",
    brand: "Adidas",
    price: 189.99,
    image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=500",
    category: "running",
    rating: 4.9,
    reviews: 456,
    colors: ["#1a1a1a", "#3b82f6"],
    sizes: [40, 41, 42, 43, 44],
    badge: null,
    new: true,
  },
  {
    id: 3,
    name: "RS-X³",
    brand: "Puma",
    price: 119.99,
    image: "https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=500",
    category: "lifestyle",
    rating: 4.6,
    reviews: 189,
    colors: ["#ffffff", "#f59e0b", "#8b5cf6"],
    sizes: [39, 40, 41, 42, 43, 44, 45, 46],
    badge: null,
    new: false,
  },
  {
    id: 4,
    name: "Jordan 1 Retro",
    brand: "Nike",
    price: 179.99,
    image: "https://images.unsplash.com/photo-1597045566677-8cf032ed6634?w=500",
    category: "basketball",
    rating: 4.9,
    reviews: 892,
    colors: ["#dc2626", "#1a1a1a", "#3b82f6"],
    sizes: [40, 41, 42, 43, 44, 45],
    badge: "Best-seller",
    new: false,
  },
  {
    id: 5,
    name: "990v5",
    brand: "New Balance",
    price: 199.99,
    image: "https://images.unsplash.com/photo-1539185441755-769473a23570?w=500",
    category: "lifestyle",
    rating: 4.7,
    reviews: 312,
    colors: ["#6b7280", "#1e40af"],
    sizes: [40, 41, 42, 43, 44, 45],
    badge: null,
    new: true,
  },
  {
    id: 6,
    name: "Gel-Kayano 29",
    brand: "Asics",
    price: 169.99,
    originalPrice: 189.99,
    image: "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=500",
    category: "running",
    rating: 4.8,
    reviews: 567,
    colors: ["#1a1a1a", "#22c55e", "#f97316"],
    sizes: [39, 40, 41, 42, 43, 44],
    badge: "Promo",
    new: false,
  },
  {
    id: 7,
    name: "Club C 85",
    brand: "Reebok",
    price: 89.99,
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=500",
    category: "lifestyle",
    rating: 4.5,
    reviews: 234,
    colors: ["#ffffff", "#1a1a1a"],
    sizes: [38, 39, 40, 41, 42, 43, 44, 45],
    badge: null,
    new: false,
  },
  {
    id: 8,
    name: "Zoom Freak 4",
    brand: "Nike",
    price: 139.99,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500",
    category: "basketball",
    rating: 4.7,
    reviews: 178,
    colors: ["#8b5cf6", "#ec4899", "#1a1a1a"],
    sizes: [40, 41, 42, 43, 44, 45, 46],
    badge: null,
    new: true,
  },
];

const features = [
  { icon: Truck, title: "Livraison gratuite", desc: "Dès 100€ d'achat" },
  { icon: RotateCcw, title: "Retours gratuits", desc: "Sous 30 jours" },
  { icon: Shield, title: "Paiement sécurisé", desc: "SSL 256-bit" },
  { icon: Package, title: "Click & Collect", desc: "En 2h en magasin" },
];

export default function EcommerceTemplate() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState("all");
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [wishlist, setWishlist] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);
  const [selectedColor, setSelectedColor] = useState(0);
  const [searchOpen, setSearchOpen] = useState(false);

  const filteredProducts = activeCategory === "all"
    ? products
    : products.filter(p => p.category === activeCategory);

  const addToCart = (product, size) => {
    const existingItem = cart.find(item => item.id === product.id && item.size === size);
    if (existingItem) {
      setCart(cart.map(item =>
        item.id === product.id && item.size === size
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { ...product, size, quantity: 1 }]);
    }
    setSelectedProduct(null);
    setIsCartOpen(true);
  };

  const removeFromCart = (productId, size) => {
    setCart(cart.filter(item => !(item.id === productId && item.size === size)));
  };

  const updateQuantity = (productId, size, delta) => {
    setCart(cart.map(item => {
      if (item.id === productId && item.size === size) {
        const newQty = item.quantity + delta;
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const toggleWishlist = (productId) => {
    setWishlist(prev =>
      prev.includes(productId)
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#fafafa] text-zinc-900">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white border-b border-zinc-200">
        {/* Top bar */}
        <div className="bg-zinc-900 text-white text-xs py-2 px-4 text-center">
          <span>🎉 Soldes d'hiver : -20% sur tout le site avec le code WINTER20</span>
        </div>

        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            {/* Logo */}
            <a href="#" className="text-2xl font-black tracking-tight ml-32 md:ml-0">
              KICK<span className="text-violet-600">STORE</span>
            </a>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-8">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`text-sm font-medium transition-colors ${
                    activeCategory === cat.id ? 'text-violet-600' : 'text-zinc-600 hover:text-zinc-900'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setSearchOpen(true)}
                className="p-2 hover:bg-zinc-100 rounded-full transition-colors"
              >
                <Search className="w-5 h-5" />
              </button>
              <button className="p-2 hover:bg-zinc-100 rounded-full transition-colors relative">
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-violet-600 text-white text-xs rounded-full flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setIsCartOpen(true)}
                className="p-2 hover:bg-zinc-100 rounded-full transition-colors relative"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-violet-600 text-white text-xs rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
              <button className="hidden md:flex p-2 hover:bg-zinc-100 rounded-full transition-colors">
                <User className="w-5 h-5" />
              </button>
              <button
                onClick={() => setIsMenuOpen(true)}
                className="lg:hidden p-2 hover:bg-zinc-100 rounded-full transition-colors"
              >
                <Menu className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1920')] bg-cover bg-center opacity-20" />
        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl"
          >
            <span className="inline-block px-4 py-1 bg-white/20 backdrop-blur rounded-full text-sm mb-6">
              Nouvelle collection 2024
            </span>
            <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
              Trouvez votre
              <br />
              <span className="text-yellow-300">style parfait</span>
            </h1>
            <p className="text-lg text-white/80 mb-8 max-w-lg">
              Découvrez les dernières tendances en sneakers. Des classiques intemporels aux éditions limitées.
            </p>
            <div className="flex flex-wrap gap-4">
              <button className="px-8 py-4 bg-white text-zinc-900 font-bold rounded-full hover:bg-zinc-100 transition-colors">
                Voir la collection
              </button>
              <button className="px-8 py-4 border-2 border-white/50 font-bold rounded-full hover:bg-white/10 transition-colors">
                Nouveautés
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-white border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {features.map((feature, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-violet-100 flex items-center justify-center flex-shrink-0">
                  <feature.icon className="w-6 h-6 text-violet-600" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{feature.title}</p>
                  <p className="text-xs text-zinc-500">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Products */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold">Nos produits</h2>
              <p className="text-zinc-500">{filteredProducts.length} articles</p>
            </div>

            {/* Mobile Categories */}
            <div className="flex gap-2 overflow-x-auto pb-2 md:hidden">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                    activeCategory === cat.id
                      ? 'bg-zinc-900 text-white'
                      : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>

            <button className="hidden md:flex items-center gap-2 px-4 py-2 border border-zinc-200 rounded-lg hover:bg-zinc-50">
              <Filter className="w-4 h-4" />
              Filtres
              <ChevronDown className="w-4 h-4" />
            </button>
          </div>

          <motion.div layout className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <AnimatePresence mode="popLayout">
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                  className="group bg-white rounded-2xl overflow-hidden border border-zinc-100 hover:shadow-xl hover:shadow-zinc-200/50 transition-all"
                >
                  {/* Image */}
                  <div className="relative aspect-square bg-zinc-100 overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Badges */}
                    <div className="absolute top-3 left-3 flex flex-col gap-2">
                      {product.new && (
                        <span className="px-2 py-1 bg-emerald-500 text-white text-xs font-bold rounded">
                          NEW
                        </span>
                      )}
                      {product.badge && (
                        <span className={`px-2 py-1 text-white text-xs font-bold rounded ${
                          product.badge === "Promo" ? "bg-red-500" : "bg-violet-600"
                        }`}>
                          {product.badge}
                        </span>
                      )}
                    </div>

                    {/* Wishlist */}
                    <button
                      onClick={() => toggleWishlist(product.id)}
                      className="absolute top-3 right-3 w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-md hover:scale-110 transition-transform"
                    >
                      <Heart className={`w-5 h-5 ${wishlist.includes(product.id) ? 'fill-red-500 text-red-500' : 'text-zinc-400'}`} />
                    </button>

                    {/* Quick add */}
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => {
                          setSelectedProduct(product);
                          setSelectedSize(null);
                        }}
                        className="w-full py-2 bg-white text-zinc-900 font-semibold rounded-lg hover:bg-zinc-100 transition-colors text-sm"
                      >
                        Ajouter au panier
                      </button>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <p className="text-xs text-zinc-400 uppercase tracking-wide">{product.brand}</p>
                    <h3 className="font-semibold mt-1 group-hover:text-violet-600 transition-colors">{product.name}</h3>

                    {/* Rating */}
                    <div className="flex items-center gap-1 mt-2">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="text-sm font-medium">{product.rating}</span>
                      <span className="text-xs text-zinc-400">({product.reviews})</span>
                    </div>

                    {/* Colors */}
                    <div className="flex gap-1 mt-3">
                      {product.colors.map((color, i) => (
                        <div
                          key={i}
                          className="w-4 h-4 rounded-full border border-zinc-200"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>

                    {/* Price */}
                    <div className="flex items-center gap-2 mt-3">
                      <span className="text-lg font-bold">{product.price}€</span>
                      {product.originalPrice && (
                        <span className="text-sm text-zinc-400 line-through">{product.originalPrice}€</span>
                      )}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          <div className="text-center mt-12">
            <button className="px-8 py-3 bg-zinc-900 text-white font-semibold rounded-full hover:bg-zinc-800 transition-colors">
              Voir plus de produits
            </button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="bg-zinc-900 text-white py-16 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Rejoignez le club</h2>
          <p className="text-zinc-400 mb-8">
            Inscrivez-vous et recevez -10% sur votre première commande + les dernières nouveautés
          </p>
          <form className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Votre email"
              className="flex-1 px-4 py-3 bg-zinc-800 border border-zinc-700 rounded-full text-white placeholder-zinc-500 focus:outline-none focus:border-violet-500"
            />
            <button className="px-6 py-3 bg-violet-600 hover:bg-violet-700 font-semibold rounded-full transition-colors">
              S'inscrire
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-zinc-200 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold mb-4">KICKSTORE</h3>
              <p className="text-sm text-zinc-500">
                Votre destination sneakers depuis 2015. Authenticité garantie.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Aide</h4>
              <ul className="space-y-2 text-sm text-zinc-500">
                <li><a href="#" className="hover:text-zinc-900">FAQ</a></li>
                <li><a href="#" className="hover:text-zinc-900">Livraison</a></li>
                <li><a href="#" className="hover:text-zinc-900">Retours</a></li>
                <li><a href="#" className="hover:text-zinc-900">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Légal</h4>
              <ul className="space-y-2 text-sm text-zinc-500">
                <li><a href="#" className="hover:text-zinc-900">CGV</a></li>
                <li><a href="#" className="hover:text-zinc-900">Mentions légales</a></li>
                <li><a href="#" className="hover:text-zinc-900">Confidentialité</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Paiement sécurisé</h4>
              <div className="flex gap-2">
                <div className="w-12 h-8 bg-zinc-100 rounded flex items-center justify-center text-xs font-bold">VISA</div>
                <div className="w-12 h-8 bg-zinc-100 rounded flex items-center justify-center text-xs font-bold">MC</div>
                <div className="w-12 h-8 bg-zinc-100 rounded flex items-center justify-center text-xs font-bold">PP</div>
              </div>
            </div>
          </div>
          <div className="pt-8 border-t border-zinc-200 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-zinc-500">
            <p>© 2024 KickStore. Tous droits réservés.</p>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/50 z-50"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white z-50 flex flex-col"
            >
              <div className="flex items-center justify-between p-4 border-b">
                <h2 className="text-lg font-bold">Panier ({cartCount})</h2>
                <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-zinc-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                  <ShoppingBag className="w-16 h-16 text-zinc-300 mb-4" />
                  <p className="text-zinc-500">Votre panier est vide</p>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="mt-4 px-6 py-2 bg-zinc-900 text-white rounded-full"
                  >
                    Continuer mes achats
                  </button>
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-auto p-4 space-y-4">
                    {cart.map((item) => (
                      <div key={`${item.id}-${item.size}`} className="flex gap-4 bg-zinc-50 rounded-xl p-3">
                        <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded-lg" />
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <div>
                              <p className="font-semibold">{item.name}</p>
                              <p className="text-sm text-zinc-500">Taille: {item.size}</p>
                            </div>
                            <button
                              onClick={() => removeFromCart(item.id, item.size)}
                              className="p-1 hover:bg-zinc-200 rounded"
                            >
                              <Trash2 className="w-4 h-4 text-zinc-400" />
                            </button>
                          </div>
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center gap-2 bg-white rounded-lg border">
                              <button
                                onClick={() => updateQuantity(item.id, item.size, -1)}
                                className="p-1 hover:bg-zinc-100"
                              >
                                <Minus className="w-4 h-4" />
                              </button>
                              <span className="w-8 text-center text-sm">{item.quantity}</span>
                              <button
                                onClick={() => updateQuantity(item.id, item.size, 1)}
                                className="p-1 hover:bg-zinc-100"
                              >
                                <Plus className="w-4 h-4" />
                              </button>
                            </div>
                            <p className="font-bold">{(item.price * item.quantity).toFixed(2)}€</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-4 border-t bg-zinc-50">
                    <div className="flex justify-between mb-2">
                      <span className="text-zinc-500">Sous-total</span>
                      <span className="font-semibold">{cartTotal.toFixed(2)}€</span>
                    </div>
                    <div className="flex justify-between mb-4">
                      <span className="text-zinc-500">Livraison</span>
                      <span className="font-semibold text-emerald-600">Gratuite</span>
                    </div>
                    <div className="flex justify-between text-lg mb-4">
                      <span className="font-bold">Total</span>
                      <span className="font-bold">{cartTotal.toFixed(2)}€</span>
                    </div>
                    <button className="w-full py-3 bg-zinc-900 text-white font-semibold rounded-full hover:bg-zinc-800 flex items-center justify-center gap-2">
                      <CreditCard className="w-5 h-5" />
                      Passer commande
                    </button>
                  </div>
                </>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Product Quick View Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="fixed inset-0 bg-black/50 z-50"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
            >
              <div className="relative w-full max-w-2xl max-h-[85vh] bg-white rounded-2xl overflow-hidden shadow-2xl">
                <div className="flex flex-col md:flex-row max-h-[85vh] overflow-auto">
                  <div className="md:w-1/2 h-64 md:h-auto bg-zinc-100 flex-shrink-0">
                    <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="md:w-1/2 p-6 flex flex-col">
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="absolute top-4 right-4 p-2 bg-white hover:bg-zinc-100 rounded-full shadow-md z-10"
                    >
                    <X className="w-5 h-5" />
                  </button>

                  <p className="text-sm text-zinc-400 uppercase">{selectedProduct.brand}</p>
                  <h3 className="text-2xl font-bold mt-1">{selectedProduct.name}</h3>

                  <div className="flex items-center gap-2 mt-2">
                    <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">{selectedProduct.rating}</span>
                    <span className="text-zinc-400">({selectedProduct.reviews} avis)</span>
                  </div>

                  <div className="flex items-center gap-2 mt-4">
                    <span className="text-2xl font-bold">{selectedProduct.price}€</span>
                    {selectedProduct.originalPrice && (
                      <span className="text-lg text-zinc-400 line-through">{selectedProduct.originalPrice}€</span>
                    )}
                  </div>

                  {/* Colors */}
                  <div className="mt-6">
                    <p className="text-sm font-medium mb-2">Couleur</p>
                    <div className="flex gap-2">
                      {selectedProduct.colors.map((color, i) => (
                        <button
                          key={i}
                          onClick={() => setSelectedColor(i)}
                          className={`w-8 h-8 rounded-full border-2 ${selectedColor === i ? 'border-violet-600' : 'border-zinc-200'}`}
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Sizes */}
                  <div className="mt-6 flex-1">
                    <p className="text-sm font-medium mb-2">Taille</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedProduct.sizes.map((size) => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`w-12 h-10 border rounded-lg font-medium transition-colors ${
                            selectedSize === size
                              ? 'border-violet-600 bg-violet-600 text-white'
                              : 'border-zinc-200 hover:border-zinc-300'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => selectedSize && addToCart(selectedProduct, selectedSize)}
                    disabled={!selectedSize}
                    className={`w-full py-3 mt-6 font-semibold rounded-full flex items-center justify-center gap-2 transition-colors ${
                      selectedSize
                        ? 'bg-zinc-900 text-white hover:bg-zinc-800'
                        : 'bg-zinc-200 text-zinc-400 cursor-not-allowed'
                    }`}
                  >
                    <ShoppingBag className="w-5 h-5" />
                    {selectedSize ? 'Ajouter au panier' : 'Sélectionnez une taille'}
                  </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/50 z-50"
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed top-0 left-0 bottom-0 w-80 bg-white z-50"
            >
              <div className="flex items-center justify-between p-4 border-b">
                <span className="text-lg font-bold">Menu</span>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-zinc-100 rounded-full">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <nav className="p-4 space-y-2">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setActiveCategory(cat.id);
                      setIsMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-3 rounded-lg hover:bg-zinc-100 font-medium flex items-center justify-between"
                  >
                    {cat.name}
                    <ChevronRight className="w-5 h-5 text-zinc-400" />
                  </button>
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Search Modal */}
      <AnimatePresence>
        {searchOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSearchOpen(false)}
              className="fixed inset-0 bg-black/50 z-50"
            />
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="fixed top-0 left-0 right-0 bg-white z-50 p-4"
            >
              <div className="max-w-2xl mx-auto">
                <div className="flex items-center gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
                    <input
                      type="text"
                      placeholder="Rechercher un produit..."
                      autoFocus
                      className="w-full pl-12 pr-4 py-3 bg-zinc-100 rounded-full focus:outline-none focus:ring-2 focus:ring-violet-500"
                    />
                  </div>
                  <button onClick={() => setSearchOpen(false)} className="p-2 hover:bg-zinc-100 rounded-full">
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
